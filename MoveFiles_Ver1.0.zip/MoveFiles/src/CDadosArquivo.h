class CDadosArquivo
{
public:
  std::string strNomeArquivo;
  time_t CriationTime;

  CDadosArquivo(std::string& pNomeArq,time_t pCriationTime=0) :strNomeArquivo(pNomeArq), CriationTime(pCriationTime){};
  ~CDadosArquivo();
  void LeDiretorio(const std::string& Caminho);

  bool operator<(const CDadosArquivo& RHS) const
  {
    return strNomeArquivo < RHS.strNomeArquivo;
  }
};

