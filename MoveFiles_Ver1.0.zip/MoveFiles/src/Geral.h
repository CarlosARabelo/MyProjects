/*typedef std::set<CDadosArquivo> tysetCDadosArquivos;
tysetCDadosArquivos::iterator ittysetCDadosArquivos;

struct lDadosArqData
{
  bool operator()(const CDadosArquivo& Arq1, const CDadosArquivo& Arq2) const
  {
    return Arq1.strDataCriacao < Arq2.strDataCriacao;
  }
};

#include <strstream>
#include <iomanip>

typedef std::set<CDadosArquivo, lDadosArqData> tysetCDadosArquivosData;
tysetCDadosArquivosData::iterator ittysetCDadosArquivosData;
*/
inline void GravaLog(const std::string& strMsg, std::ostream& Stream, bool ForcarHora)
{
  time_t Now(time(0));
  static time_t Previous(Now);
  std::strstream strstreamTemp;

  strstreamTemp << std::right << std::fixed << std::setfill(' ') << std::setprecision(2);

  if (ForcarHora || (Now - Previous) > 30L)  //--- Just show time on lapse of 30s
  {
	tm *ltm(localtime(&Now));

    strstreamTemp << "====> " << ltm->tm_mday << '/' << ltm->tm_mon << '/' << ltm->tm_year << " " << ltm->tm_hour << ':' << ltm->tm_min << ':' << ltm->tm_sec << ' ' << std::ends;
    Stream << strstreamTemp.str();
    Previous = Now;
  }

  Stream << strMsg.c_str() << std::endl;

  Stream.flush();
}

