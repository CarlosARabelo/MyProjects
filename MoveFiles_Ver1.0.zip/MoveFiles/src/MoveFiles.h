typedef std::set<CDadosArquivo> tysetCDadosArquivos;
typedef tysetCDadosArquivos::iterator ittysetCDadosArquivos;

struct lDadosArqData
{
  bool operator()(const CDadosArquivo& Arq1, const CDadosArquivo& Arq2) const
  {
    return Arq1.CriationTime < Arq2.CriationTime;
  }
};

typedef std::set<CDadosArquivo, lDadosArqData> tysetCDadosArquivosDate;
typedef tysetCDadosArquivosDate::iterator ittysetCDadosArquivosDate;

class CMoverArquivosApp 
{
public:
	CMoverArquivosApp();

// Substitui
public:

  void MoveFiles(const std::string& Sorce, const std::string& Destination, const tysetCDadosArquivos& DadosArquivos);
  void LeDiretorio(const std::string& Caminho, tysetCDadosArquivos& DadosArquivos, const std::string& WildCard);


};


