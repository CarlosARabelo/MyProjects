#include <string>
#include "CDadosArquivo.h"

CDadosArquivo::~CDadosArquivo()
{
}

