//============================================================================
// Name        : MoveFiles.cpp
// Author      : Carlos A. Rabelo
// Version     : 1.0
// Copyright   : Your copyright notice
// Description : Movefiles in C++, Ansi-style
//============================================================================

#include <iostream>
#include <map>
#include <fstream>
#include "CArqConfig.h"
#include <strstream>
#include <iomanip>
#include "Geral.h"
#include <set>
#include "CDadosArquivo.h"
#include "MoveFiles.h"
#include <unistd.h>

int LeDiretorio(const std::string& Caminho, tysetCDadosArquivos& DadosArquivos,const std::string& WildCard,const std::string& RegEx);
void MoveFiles(const std::string& Source, const std::string& Destination, const tysetCDadosArquivos& DadosArquivos);
time_t getFileModificationTime(std::string& path);

std::ofstream ofArqLog("CalcSuperficie.log", std::ios_base::app);

int main()
{
  ofArqLog << "===> Program started ======================================================" << std::endl;

  if (ofArqLog.good() == false)
  {
	std::cout << "Error opening log file, program aborted.";
	return false;
  }

  CArqConfig ArqConfig(".\\");

  if (ArqConfig.Ok())
  {
    tysetCDadosArquivos DadosArquivos;
	ulong TimeLapse(atol(ArqConfig.GetTimeLapse().c_str()));

	if(TimeLapse < 10)
	{
	  std::string Error("Error: Time Lapse too small, program aborted");

	  ofArqLog << Error.c_str();
	  std::cout << Error.c_str();

	  return 1;
	}

	TimeLapse *= 1E6;
	bool OK(true);

	while(OK)
	{
	  DadosArquivos.clear();

	  LeDiretorio(ArqConfig.GetSource(),DadosArquivos, ArqConfig.GetWildCard(),ArqConfig.GetRegEx());

	  if(DadosArquivos.size() > 0)
	  {
	    std::string strModeOperation(ArqConfig.GetModeOperation());

	    //--- If the operation mode is "Newest" or "Oldest", separate the only file respectively.
	    //--- On any of these cases only one file remains on the DadosArquivos structure,
	    //--- the newest or the oldest.
	    //--- If the operation mode is "Name", move to destination directory all files scanned
	    //--- on source directory.

	    if(strModeOperation.compare("Newest") == 0)
	    {
		   ittysetCDadosArquivos itErlier(DadosArquivos.begin());

		   for(ittysetCDadosArquivos it = ++DadosArquivos.begin() ; it != DadosArquivos.end() ; it++)
		   {
             if(it->CriationTime < itErlier->CriationTime) itErlier = it;
		   }

		   for(ittysetCDadosArquivos it = DadosArquivos.begin() ; it != DadosArquivos.end() ;)
		   {
		     if (it != itErlier) DadosArquivos.erase(it++);
		     else it++;
		   }
	    }
	    else
	    if(strModeOperation.compare("Oldest") == 0)
	    {
	      ittysetCDadosArquivos itLater(DadosArquivos.begin());

	  	  for(ittysetCDadosArquivos it = ++DadosArquivos.begin() ; it != DadosArquivos.end() ; it++)
	  	  {
	        if(it->CriationTime > itLater->CriationTime) itLater = it;
	  	  }

	  	  for(ittysetCDadosArquivos it = DadosArquivos.begin() ; it != DadosArquivos.end() ;)
	  	  {
	  	    if (it != itLater) DadosArquivos.erase(it++);
	  	    else it++;
	  	  }
	    }

	    MoveFiles(ArqConfig.GetSource(), ArqConfig.GetDestination(), DadosArquivos);

	  //  usleep(TimeLapse);
	    OK = false;
      }
    }
  }
  else
  {
	std::cout << "Error reading configuration file, see log file for details" << std::endl;
	ofArqLog << "Error reading ConfigFile on line " << ArqConfig.GetStatus() << std::endl;

	return 2;
  }

  ofArqLog << "===> Program Finished ======================================================" << std::endl;
  ofArqLog.flush();

  return 0;
}

#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>

int LeDiretorio(const std::string& Caminho, tysetCDadosArquivos& DadosArquivos,const std::string& WildCard,const std::string& RegEx)
{
  DIR *dp;
  struct dirent *dirp;

  if((dp  = opendir(Caminho.c_str())) == NULL)
  {
	std::cout << "Error(" << errno << ") opening " << Caminho.c_str() << std::endl;
	return errno;
  }

  tysetCDadosArquivos DadosArquivos2;

  //--- Read name and date of all files

  while ((dirp = readdir(dp)) != NULL)
  {
    std::string FileName(dirp->d_name);
    time_t FileTime(getFileModificationTime(FileName));

    if(FileName.compare(".") != 0 && FileName.compare("..") != 0)
    {
  	  DadosArquivos2.emplace(CDadosArquivo(FileName,FileTime));
    }
  }

  closedir(dp);

  //--- Read the selected files (Accept regular expressions or WildCards)

  std::stringstream strstrCmd;

  strstrCmd << "ls " << Caminho.c_str() << "/";

  if(RegEx.size() > 0) strstrCmd <<  " | egrep "  << RegEx;
  else if(WildCard.size() > 0) strstrCmd << WildCard;

  strstrCmd << " -1 > " << Caminho.c_str() << '/' << "Temp_Mov_Files.txt" << std::ends;

  system(strstrCmd.str().c_str());

  std::string NameTempFile(Caminho.c_str());
  NameTempFile += "/Temp_Mov_Files.txt";

  std::ifstream TempMovFiles(NameTempFile);

  if(TempMovFiles.good() == true)
  {
	char LinhaArq[255]={0};

	do
	{
	  TempMovFiles.getline(LinhaArq,255);

	  std::string strNameArqAtual(LinhaArq);

	  strNameArqAtual = strNameArqAtual.substr(strNameArqAtual.find_last_of('/')+1);
	  CDadosArquivo ArqAtual(strNameArqAtual);

	  ittysetCDadosArquivos itArqAtual(DadosArquivos2.find(ArqAtual));

	  //--- Keep only the selected files

	  if(itArqAtual != DadosArquivos2.end()) DadosArquivos.insert(*itArqAtual);

    }while (TempMovFiles.good());
  }

  strstrCmd << "rm " << Caminho.c_str() << '/' << "Temp_Mov_Files.txt" << std::ends;

  system(strstrCmd.str().c_str());

  return 0;
}

void MoveFiles(const std::string& Source, const std::string& Destination, const tysetCDadosArquivos& DadosArquivos)
{
  std::string SourceName,DestName;

  for (ittysetCDadosArquivos it = DadosArquivos.begin(); it != DadosArquivos.end(); it++)
  {
    SourceName = Source + '/' + it->strNomeArquivo;
    DestName = Destination + '/' + it->strNomeArquivo;

    std::stringstream strstrCmd;

    strstrCmd << "cp " << SourceName.c_str() << ' ' << DestName.c_str() << std::ends;

    std::string CMD(strstrCmd.str());

    system(strstrCmd.str().c_str());

  }
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

time_t getFileModificationTime(std::string& path)
{
  struct stat attr;
  stat(path.c_str(), &attr);

  return attr.st_mtime;
}

