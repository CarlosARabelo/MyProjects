typedef std::map<std::string, std::string> tymapConfiguracao;
typedef tymapConfiguracao::const_iterator cittymapConfiguracao;
typedef std::pair<std::string,std::string> typairstrstr;

class CArqConfig
{
  int Status;
  std::ifstream ifArqConfig;
  tymapConfiguracao MapConfiguracao;
  int Erro;

public:
  CArqConfig(const std::string& Caminho);
  ~CArqConfig();
  bool Ok() { return Status == 0; };
  int GetStatus() { return Status; }
  inline void Trim(std::string& Data, int Side = 0);   //--- Remove spaces: side = 0->both, 1->left, 2->right
  inline void RemoveDirt(std::string& Data);           //--- Remove Dirt characters from the string

  const std::string GetSource() const 
  { 
    cittymapConfiguracao it(MapConfiguracao.find("Source"));
    if (it == MapConfiguracao.end()) return "";

    return it->second;
  };

  const std::string GetDestination() const 
  {
    cittymapConfiguracao it(MapConfiguracao.find("Destination"));
    if (it == MapConfiguracao.end()) return "";
    return it->second; 
  };

  const std::string GetWildCard() const 
  { 
    cittymapConfiguracao it(MapConfiguracao.find("WildCard"));
    if (it == MapConfiguracao.end()) return "";

    return it->second; 
  };

  const std::string GetTimeLapse() const
  {
    cittymapConfiguracao it(MapConfiguracao.find("Lapse"));
    if (it == MapConfiguracao.end()) return "";

    return it->second;
  };

  const std::string GetModeOperation() const
  {
    cittymapConfiguracao it(MapConfiguracao.find("Mode"));
    if (it == MapConfiguracao.end()) return "";

    return it->second;
  };

  const std::string GetRegEx() const
  {
    cittymapConfiguracao it(MapConfiguracao.find("RegEx"));
    if (it == MapConfiguracao.end()) return "";

    return it->second;
  };

};

