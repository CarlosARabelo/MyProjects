#include <map>
#include <iostream>    
#include <fstream>   
#include "CArqConfig.h"
#include <algorithm>
#include <cctype>
#include <string.h>

CArqConfig::CArqConfig(const std::string& strDiretorio):Status(0),Erro(0)
{
   //--- Read the configuration file

  ifArqConfig.open("Config.txt", std::ios_base::in);

  if (ifArqConfig.good() == true)
  {
    std::string Comentarios("!#*");
    char LinhaArq[256];
    int Contalinhas(0);

    do
    {
      ifArqConfig.getline(LinhaArq, 255);
      Contalinhas++;

      if (ifArqConfig.good() || ifArqConfig.eof())
      {
        if (strlen(LinhaArq) > 2 && std::find(Comentarios.begin(), Comentarios.end(), LinhaArq[0]) == Comentarios.end())   //--- N�o � coment�rio?
        {
          char* TokenIgual(std::find(LinhaArq, LinhaArq + 255, '='));

          if (TokenIgual != NULL)          //=== Tem o sinal =?
          {
            typairstrstr PairStrStr(std::string(LinhaArq, TokenIgual), std::string(TokenIgual+1));

            //--- To avoid errors remove dirt characters and spaces on the begin and the end of the strings.

            RemoveDirt(PairStrStr.first);
            RemoveDirt(PairStrStr.second);

            Trim(PairStrStr.first);
            Trim(PairStrStr.second);

            MapConfiguracao.insert(PairStrStr);
          }
        }
      }
    } while (ifArqConfig.good());

    if (!ifArqConfig.eof())
    {
      Erro = Contalinhas; //--- Error on configuration file, on line Contalinhas
    }
  }
  else
  {
    std::cout << "Error opening the log file. Program aborted.";
    Status = 0;
  }
}

CArqConfig::~CArqConfig()
{
}

inline void CArqConfig::Trim(std::string& Data, int Side)   //--- Remove spaces: side = 0->both, 1->left, 2->right
{
  if (Side == 0 || Side == 1)
  {
    while (Data.begin() != Data.end() && *Data.begin() == ' ')Data.erase(Data.begin());
  }

  if (Side == 0 || Side == 2)
  {
    while (Data.rbegin() != Data.rend() && *Data.rbegin() == ' ') Data.pop_back();
  }
}

inline void CArqConfig::RemoveDirt(std::string& Data)   //--- Remove dirt characters from the string
{
	std::string Dirt("\r\n\t");

	std::string Rasc;


	for(std::string::iterator it = Data.begin() ; it != Data.end() ; it++)
	{
		if(Dirt.find(*it) == std::string::npos) Rasc += *it;
	}

	Data = Rasc;
}
